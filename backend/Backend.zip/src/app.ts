import dotenv from 'dotenv';
dotenv.config();

import express, { Request, Response, NextFunction } from 'express';
import cors from 'cors';
import path from 'path';
import routes from './routes';
import requestLogger from './middleware/requestLogger';
import logger from './utils/logger';

const app = express();

app.use(cors());
app.use(express.json());
app.use(requestLogger);

app.use((req: Request, res: Response, next: NextFunction) => {
  const start = Date.now();
  res.on('finish', () => {
    const duration = Date.now() - start;
    const statusColor = res.statusCode >= 400 ? 'error' : res.statusCode >= 300 ? 'warn' : 'info';
    const method = req.method.padEnd(6);
    const url = req.url.padEnd(40);
    const statusEmoji = res.statusCode >= 400 ? 'X' : res.statusCode >= 300 ? '!' : 'OK';
    const logLevel = statusColor === 'error' ? 'error' : statusColor === 'warn' ? 'warn' : 'http';
    logger.log(logLevel, `${statusEmoji} ${method} ${url} ${res.statusCode} - ${duration}ms`);
  });
  next();
});

app.use('/uploads', express.static(path.join(__dirname, '../uploads')));

app.use(routes);

app.get('/health', (_req: Request, res: Response) => {
  logger.info('Health check requested');
  res.json({ status: 'ok', message: 'Server is running' });
});

app.use((err: Error, req: Request, res: Response, _next: NextFunction) => {
  logger.error(`ERROR: ${err.message}`);
  logger.error(`   Route: ${req.method} ${req.url}`);
  logger.error(`   Stack: ${err.stack}`);
  res.status(500).json({ error: 'Something went wrong!' });
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log('\n' + '='.repeat(60));
  logger.info('Cricket Match Management API Server Started');
  console.log('='.repeat(60));
  logger.info(`Port: ${PORT}`);
  logger.info(`Environment: ${process.env.NODE_ENV || 'development'}`);
  logger.info(`Log Level: ${process.env.LOG_LEVEL || 'info'}`);
  logger.info(`Health Check: http://localhost:${PORT}/health`);
  logger.info(`Logs Directory: ./logs/`);
  console.log('='.repeat(60) + '\n');
  logger.info('Server ready to accept requests...\n');
});

export default app;
