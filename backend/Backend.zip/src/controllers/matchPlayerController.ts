import { Response } from 'express';
import prisma from '../config/database';
import toSnake from '../utils/toSnake';
import { AuthRequest } from '../middleware/auth';

const joinMatch = async (req: AuthRequest, res: Response): Promise<void> => {
  const { team } = req.body;
  try {
    const matchPlayer = await prisma.matchPlayer.create({
      data: {
        matchId: parseInt(req.params.id as string),
        playerId: req.user.id,
        team: team || null,
      },
    });
    res.status(201).json(toSnake(matchPlayer));
  } catch (error: unknown) {
    const err = error as { code?: string; message: string };
    if (err.code === 'P2002') {
      res.status(400).json({ error: 'Already joined this match' });
      return;
    }
    res.status(500).json({ error: err.message });
  }
};

const getMatchPlayers = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const matchId = parseInt(req.params.id as string);

    const match = await prisma.match.findUnique({
      where: { id: matchId },
      select: { team1Name: true, team2Name: true },
    });

    if (!match) {
      res.status(404).json({ error: 'Match not found' });
      return;
    }

    const players = await prisma.matchPlayer.findMany({
      where: { matchId },
      include: {
        player: {
          select: {
            name: true,
            battingStyle: true,
            bowlingStyle: true,
            phone: true,
          },
        },
      },
      orderBy: [{ team: 'asc' }, { status: 'asc' }],
    });

    const teams = await prisma.team.findMany({
      where: {
        teamName: {
          in: [match.team1Name, match.team2Name],
        },
      },
      select: { id: true, teamName: true },
    });

    const teamIds = teams.map((t) => t.id);

    const teamPlayers = await prisma.teamPlayer.findMany({
      where: {
        teamId: {
          in: teamIds,
        },
      },
      include: {
        player: {
          select: {
            name: true,
          },
        },
      },
    });

    const playerRoleMap = new Map(
      teamPlayers.map((tp) => [tp.player.name.toLowerCase(), {
        isCaptain: tp.isCaptain,
        isWicketKeeper: tp.isWicketKeeper,
      }])
    );

    const flattenedPlayers = players.map((mp) => {
      const roleInfo = playerRoleMap.get(mp.player?.name?.toLowerCase() || '');
      return {
        id: mp.id,
        match_id: mp.matchId,
        player_id: mp.playerId,
        team: mp.team,
        status: mp.status,
        name: mp.player?.name,
        batting_style: mp.player?.battingStyle,
        bowling_style: mp.player?.bowlingStyle,
        is_captain: roleInfo?.isCaptain ?? false,
        is_wicket_keeper: roleInfo?.isWicketKeeper ?? false,
      };
    });

    res.json(toSnake(flattenedPlayers));
  } catch (error: unknown) {
    const err = error as { message: string };
    res.status(500).json({ error: err.message });
  }
};

const approveMatchPlayer = async (req: AuthRequest, res: Response): Promise<void> => {
  const { status, team } = req.body;
  try {
    const data: Record<string, unknown> = { status: status || 'approved' };
    if (team) data.team = team;

    const matchPlayer = await prisma.matchPlayer.update({
      where: { id: parseInt(req.params.id as string) },
      data,
    });
    res.json(toSnake(matchPlayer));
  } catch (error: unknown) {
    const err = error as { message: string };
    res.status(500).json({ error: err.message });
  }
};

const getApprovedPlayers = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const players = await prisma.matchPlayer.findMany({
      where: {
        matchId: parseInt(req.params.id as string),
        status: 'approved',
      },
      include: {
        player: {
          select: {
            name: true,
            battingStyle: true,
            bowlingStyle: true,
          },
        },
      },
      orderBy: [{ team: 'asc' }],
    });

    const flattenedPlayers = players.map((mp) => ({
      id: mp.id,
      match_id: mp.matchId,
      player_id: mp.playerId,
      team: mp.team,
      status: mp.status,
      name: mp.player?.name,
      batting_style: mp.player?.battingStyle,
      bowling_style: mp.player?.bowlingStyle,
    }));

    res.json(toSnake(flattenedPlayers));
  } catch (error: unknown) {
    const err = error as { message: string };
    res.status(500).json({ error: err.message });
  }
};

const populateMatchPlayers = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const matchId = parseInt(req.params.id as string);

    const match = await prisma.match.findUnique({
      where: { id: matchId },
    });

    if (!match) {
      res.status(404).json({ error: 'Match not found' });
      return;
    }

    const team1 = await prisma.team.findFirst({
      where: { teamName: match.team1Name },
      include: {
        teamPlayers: {
          include: {
            player: {
              select: {
                id: true,
                name: true,
                battingStyle: true,
                bowlingStyle: true,
              },
            },
          },
        },
      },
    });

    const team2 = await prisma.team.findFirst({
      where: { teamName: match.team2Name },
      include: {
        teamPlayers: {
          include: {
            player: {
              select: {
                id: true,
                name: true,
                battingStyle: true,
                bowlingStyle: true,
              },
            },
          },
        },
      },
    });

    const createdPlayers: unknown[] = [];

    const processTeamPlayers = async (
      teamData: typeof team1,
      teamNumber: number
    ): Promise<void> => {
      if (!teamData) return;
      for (const tp of teamData.teamPlayers) {
        const registeredPlayer = tp.player;

        let user = await prisma.user.findFirst({
          where: {
            email: `player_${registeredPlayer.id}@temp.com`,
          },
        });

        if (!user) {
          user = await prisma.user.create({
            data: {
              name: registeredPlayer.name,
              email: `player_${registeredPlayer.id}@temp.com`,
              password: 'temp123',
              role: 'player',
              battingStyle: registeredPlayer.battingStyle,
              bowlingStyle: registeredPlayer.bowlingStyle,
              approved: true,
            },
          });
        }

        const existing = await prisma.matchPlayer.findUnique({
          where: {
            matchId_playerId: {
              matchId,
              playerId: user.id,
            },
          },
        });

        if (!existing) {
          const matchPlayer = await prisma.matchPlayer.create({
            data: {
              matchId,
              playerId: user.id,
              team: teamNumber,
              status: 'approved',
            },
          });
          createdPlayers.push(matchPlayer);
        }
      }
    };

    await processTeamPlayers(team1, 1);
    await processTeamPlayers(team2, 2);

    res.json({
      message: 'Match players populated successfully',
      count: createdPlayers.length,
    });
  } catch (error: unknown) {
    const err = error as { message: string };
    res.status(500).json({ error: err.message });
  }
};

export default {
  joinMatch,
  getMatchPlayers,
  approveMatchPlayer,
  getApprovedPlayers,
  populateMatchPlayers,
};
